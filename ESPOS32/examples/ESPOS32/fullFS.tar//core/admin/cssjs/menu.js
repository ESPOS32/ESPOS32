function resizeIframeToContent(iframe) {
    if (!iframe || !iframe.contentWindow || !iframe.contentDocument) return;

    const doc = iframe.contentDocument;
    const body = doc.body;
    const html = doc.documentElement;

    const height = Math.max(
        body.scrollHeight,
        body.offsetHeight,
        html.clientHeight,
        html.scrollHeight,
        html.offsetHeight
    );

    iframe.style.height = height + 'px';
}
/*
window.addEventListener('load', function () {
    const iframe = document.getElementById('ifr');
    if (!iframe) return;

    // első betöltéskor
    iframe.addEventListener('load', function () {
        resizeIframeToContent(iframe);
    });

    // ha a belső tartalom JS-ből változik, időnként újramérheted:
    // setInterval(() => resizeIframeToContent(iframe), 500);
});
*/